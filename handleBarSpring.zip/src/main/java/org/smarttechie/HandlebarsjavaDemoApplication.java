package org.smarttechie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandlebarsjavaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandlebarsjavaDemoApplication.class, args);
	}
}
